import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test2',
  template: `
    <h1>
      test2 works!
    </h1>
  `,
  styles: [
    `
    h1{
      color:red;
    }
    `
  ]
})
export class Test2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
