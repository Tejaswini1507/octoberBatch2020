import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Day3DemoComponent } from './day3-demo.component';

describe('Day3DemoComponent', () => {
  let component: Day3DemoComponent;
  let fixture: ComponentFixture<Day3DemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Day3DemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Day3DemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
