import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day3-demo',
  templateUrl: './day3-demo.component.html',
  styleUrls: ['./day3-demo.component.css']
})
export class Day3DemoComponent implements OnInit {

  displaymsg:string=" ";
  displaytxt:string="using hidden";
  ishidden:boolean=true;
  name:string;

  // class binding
  // isvalid="valid";
  // ifNot:string="notvalid";
  ifValid:string="";

  constructor() { }

  ngOnInit() {
    
  }
  
  onClick(){
    console.log("Event binding works!!");
    this.displaymsg="Event binding works!!";
  }
  onClick1(){
    this.ishidden=false;
  }
  onDisplay(value){
    console.log(value);
    console.log(value.type);
  }
  onUser(name){
    if(name=='admin'){
      console.log("valid username");
      alert("valid username");
      
    }
    else{
      console.log("invalid username");
    }
  }

}
