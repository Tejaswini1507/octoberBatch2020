import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-day3-data-binding',
  templateUrl: './day3-data-binding.component.html',
  styleUrls: ['./day3-data-binding.component.css']
})
export class Day3DataBindingComponent implements OnInit {

  // class binding
  iserror:string="error";
  isSucceess:string="success";

  // 
  anyStyle:boolean=true;
  anyError:boolean=false;
  rating:number=3;

  // ngClass
  myObj={
    "success":!this.anyError,
    "error":this.anyError,
    "mystyle":this.anyStyle
  }
  constructor() { }

  ngOnInit() {
  }

}
