import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Day3DataBindingComponent } from './day3-data-binding.component';

describe('Day3DataBindingComponent', () => {
  let component: Day3DataBindingComponent;
  let fixture: ComponentFixture<Day3DataBindingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Day3DataBindingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Day3DataBindingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
