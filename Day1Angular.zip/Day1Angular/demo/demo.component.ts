import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {
  
  name:string="Tejaswini";
  myNum:number=7;

  // Diff between str interpolation and property binding
  isHidden:boolean=true;

  constructor() { }

  ngOnInit() {
  }

}
